function swappedList = swap( List, i, j )

swappedList = List;

swappedList(i) = List(j); 
swappedList(j) = List(i); 
end

