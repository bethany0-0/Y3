function [avg_cost,avg_vio] = Times(file, MaxIter, Reps)


for i = 1:Reps
 Run(file, MaxIter)
   
end


end